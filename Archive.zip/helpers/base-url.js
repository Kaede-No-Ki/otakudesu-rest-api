module.exports = {
    baseUrl: 'https://otakudesu.moe/',
    completeAnime:'complete-anime/',
    onGoingAnime:'ongoing-anime/',
    schedule:'jadwal-rilis/',
    genreList:'genre-list/'
};
